import React, { useState } from 'react';
import {
  LayoutDashboard,
  Calculator,
  Layers,
  ShoppingBag,
  TrendingUp,
  HelpCircle,
  Settings,
  ChevronDown,
  Menu,
  X,
  PlusCircle,
} from 'lucide-react';

export type NavSection =
  | 'dashboard'
  | 'calculator'
  | 'library'
  | 'products'
  | 'simulator'
  | 'help'
  | 'settings';

interface NavigationProps {
  currentSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  onNewCalculation: () => void;
}

export const NAV_ITEMS: { id: NavSection; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'calculator', label: 'Product Calculator', icon: Calculator },
  { id: 'library', label: 'Materials Library', icon: Layers },
  { id: 'products', label: 'My Products', icon: ShoppingBag },
  { id: 'simulator', label: 'Profit Simulator', icon: TrendingUp },
  { id: 'help', label: 'Help & Guides', icon: HelpCircle },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export const Navigation: React.FC<NavigationProps> = ({
  currentSection,
  onSelectSection,
  onNewCalculation,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleMobileNavChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value as NavSection;
    if (val) {
      onSelectSection(val);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleItemClick = (id: NavSection) => {
    onSelectSection(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* MOBILE HEADER & FIXED TOP BAR */}
      <div className="lg:hidden bg-[#253a35] text-cream border-b border-[#344d47] px-4 py-3 sticky top-0 z-40 shadow-md">
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <span className="font-serif-brand font-bold text-lg tracking-tight text-[#f8f6ef]">
              This Man Makes
            </span>
            <span className="text-[10px] tracking-wider uppercase px-2 py-0.5 rounded-full bg-[#39564e] text-emerald-100 font-semibold">
              UK Craft Pricing
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onNewCalculation}
              className="px-2.5 py-1.5 rounded-lg bg-[#286d60] hover:bg-[#20594f] active:bg-[#18463e] text-white text-xs font-semibold flex items-center gap-1 shadow-sm transition-colors"
              title="Start New Product Calculation"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>New</span>
            </button>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 rounded-lg text-emerald-100 hover:text-white hover:bg-[#344d47] active:bg-[#405c55] transition-colors"
              aria-label="Toggle navigation drawer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* MOBILE SELECT DROPDOWN (Enhanced with guaranteed mobile touch/change handlers and 16px font to prevent iOS zoom) */}
        <div className="relative">
          <label htmlFor="mobile-section-select" className="sr-only">
            Select Section
          </label>
          <div className="relative flex items-center">
            <select
              id="mobile-section-select"
              value={currentSection}
              onChange={handleMobileNavChange}
              className="w-full appearance-none bg-[#1d2d29] text-white border border-[#3e5b53] rounded-xl px-4 py-3 pr-10 text-base font-medium shadow-inner focus:outline-none focus:ring-2 focus:ring-[#db9b47] focus:border-transparent transition"
            >
              {NAV_ITEMS.map((item) => (
                <option key={item.id} value={item.id} className="bg-[#253a35] text-white py-1">
                  {item.label}
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute right-3 text-emerald-200">
              <ChevronDown className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* MOBILE QUICK PILLS CAROUSEL FOR ONE-TAP ACCESS */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-2 text-xs">
          {NAV_ITEMS.map((item) => {
            const isActive = currentSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleItemClick(item.id)}
                className={`whitespace-nowrap px-3 py-1.5 rounded-full font-medium transition-all ${
                  isActive
                    ? 'bg-[#286d60] text-white shadow-sm font-semibold ring-1 ring-emerald-300/40'
                    : 'bg-[#1b2b27] text-zinc-300 hover:text-white hover:bg-[#324b44]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>

        {/* MOBILE SLIDE-DOWN DRAWER MENU */}
        {mobileMenuOpen && (
          <div className="mt-2 pt-2 border-t border-[#344d47] space-y-1 pb-1 animate-in fade-in slide-in-from-top-2 duration-150">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = currentSection === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleItemClick(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition text-left ${
                    isActive
                      ? 'bg-[#426558] text-white font-semibold shadow-sm'
                      : 'text-[#d6ded9] hover:bg-[#344d47] hover:text-white'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-emerald-300/70'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* DESKTOP SIDEBAR */}
      <aside className="hidden lg:flex w-64 flex-none bg-[#253a35] text-[#f8f6ef] p-6 flex-col gap-2 min-h-screen sticky top-0 select-none shadow-xl border-r border-[#1e302c]">
        {/* Brand */}
        <div className="px-3 pt-2 pb-6 border-b border-[#344d47]/60">
          <h1 className="font-serif-brand text-2xl font-bold tracking-tight text-[#f8f6ef]">
            This Man Makes
          </h1>
          <div className="text-[11px] font-semibold tracking-wider text-emerald-200/70 uppercase mt-1">
            UK Craft Pricing Workspace
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="flex flex-col gap-1.5 mt-4" aria-label="Main navigation">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = currentSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleItemClick(item.id)}
                className={`flex items-center gap-3.5 w-full text-left px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-[#426558] text-white font-semibold shadow-md translate-x-1 ring-1 ring-white/10'
                    : 'text-[#e5e9e3] hover:bg-[#344d47] hover:text-white'
                }`}
              >
                <Icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-emerald-200' : 'text-emerald-300/60'
                  }`}
                />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Quick Action Button */}
        <div className="mt-4 px-1">
          <button
            type="button"
            onClick={onNewCalculation}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#286d60] hover:bg-[#20594f] active:bg-[#1a4a41] text-white font-semibold text-sm shadow-sm transition"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New Calculation</span>
          </button>
        </div>

        {/* Disclaimer Footer */}
        <div className="mt-auto pt-6 border-t border-[#344d47]/60 text-xs text-emerald-200/50 px-2 leading-relaxed">
          Estimates for craft pricing. Not guaranteed earnings or formal tax advice.
        </div>
      </aside>
    </>
  );
};
