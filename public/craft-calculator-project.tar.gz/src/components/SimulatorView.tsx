import React, { useState } from 'react';
import {
  TrendingUp,
  Percent,
  Sliders,
  DollarSign,
  ArrowRight,
  Info,
} from 'lucide-react';
import { SavedProduct } from '../types/calculator';
import { formatMoney, formatPct, calculatePriceResult, calculateTargetPrice } from '../utils/calculator';

interface SimulatorViewProps {
  currentProduct?: SavedProduct | null;
}

export const SimulatorView: React.FC<SimulatorViewProps> = ({ currentProduct }) => {
  const [customPrice, setCustomPrice] = useState<number>(currentProduct?.selling_price ? currentProduct.selling_price * 1.15 : 22.0);
  const [customQty, setCustomQty] = useState<number>(30);
  const [customDiscount, setCustomDiscount] = useState<number>(15);

  const prodCost = currentProduct?.production_cost || 7.5;
  const currPrice = currentProduct?.selling_price || 16.0;
  const targetMargin = (currentProduct?.pricing?.targetMargin || 30) / 100;

  const baseParams = {
    productionCost: prodCost,
    actualPostage: currentProduct?.postage?.actualPaid || 2.85,
    extraPostalPackaging: currentProduct?.postage?.extraPackaging || 0.35,
    fulfilment: currentProduct?.postage?.otherFulfilment || 0,
    recoverableInputVat: currentProduct?.vat?.recoverableInputVat || 0,
    chargedPostage: currentProduct?.postage?.freeCustomerPostage ? 0 : currentProduct?.postage?.chargedToCustomer || 3.5,
    freePostage: Boolean(currentProduct?.postage?.freeCustomerPostage),
    vatRegistered: Boolean(currentProduct?.vat?.vatRegistered),
    vatRate: (currentProduct?.vat?.vatRate || 20) / 100,
    vatInclusive: Boolean(currentProduct?.vat?.vatInclusive ?? true),
    feeEnabled: Boolean(currentProduct?.fees?.feeEnabled ?? true),
    feePostage: Boolean(currentProduct?.fees?.feesApplyToPostage ?? true),
    feeValues: currentProduct?.fees?.feeValues || [6.5, 0.2, 0, 0, 0, 0, 0],
    orderCount: currentProduct?.fees?.itemsPerOrder || 1,
  };

  const breakevenPrice = calculateTargetPrice(0, baseParams);
  const recommendedPrice = calculateTargetPrice(targetMargin, baseParams);

  const scenarios: { name: string; price: number; description: string }[] = [
    { name: 'Break-even', price: breakevenPrice, description: 'Zero profit, covers all entered costs and fees' },
    { name: 'Lower (-10%)', price: currPrice * 0.9, description: 'Promotional or clearance pricing' },
    { name: 'Current Selling Price', price: currPrice, description: 'Your currently set retail price' },
    { name: 'Recommended Target Price', price: Math.ceil(recommendedPrice * 100) / 100, description: `Achieves your target ${(targetMargin * 100).toFixed(0)}% profit margin` },
    { name: 'Premium (+20%)', price: currPrice * 1.2, description: 'Luxury or gift-season pricing' },
    { name: 'Custom Simulation Price', price: customPrice, description: 'Your custom experimental price point' },
  ];

  const salesVolumes = [10, 25, 50, 100, customQty];

  const discounts = [5, 10, 15, 20, customDiscount];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="pb-4 border-b border-[#dddcd3]">
        <h2 className="font-serif-brand text-2xl font-bold text-[#202c29]">
          Profit Simulator & Sales Scenarios
        </h2>
        <p className="text-xs text-[#626d68] mt-1">
          Explore how varying retail prices, promotional discounts and sales volumes impact your take-home craft earnings.
          {currentProduct && (
            <span className="font-semibold text-[#286d60] ml-1">
              (Simulating: {currentProduct.name})
            </span>
          )}
        </p>
      </div>

      {/* Control Panel */}
      <div className="bg-[#fffefa] border border-[#dddcd3] rounded-2xl p-5 sm:p-6 shadow-xs">
        <h3 className="font-serif-brand text-lg font-bold text-[#202c29] mb-3 flex items-center gap-2">
          <Sliders className="w-4 h-4 text-[#286d60]" />
          <span>Interactive Simulation Variables</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-bold text-[#202c29] mb-1.5">
              Custom Scenario Price (£)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={customPrice}
              onChange={(e) => setCustomPrice(parseFloat(e.target.value) || 0)}
              className="w-full text-base sm:text-sm bg-white border border-[#c8d0c9] rounded-xl px-3.5 py-2.5 text-[#202c29] focus:outline-none focus:ring-2 focus:ring-[#286d60]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#202c29] mb-1.5">
              Custom Sales Volume Target (Units)
            </label>
            <input
              type="number"
              min="1"
              step="1"
              value={customQty}
              onChange={(e) => setCustomQty(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-full text-base sm:text-sm bg-white border border-[#c8d0c9] rounded-xl px-3.5 py-2.5 text-[#202c29] focus:outline-none focus:ring-2 focus:ring-[#286d60]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#202c29] mb-1.5">
              Custom Promotional Discount (%)
            </label>
            <input
              type="number"
              min="0"
              max="100"
              step="any"
              value={customDiscount}
              onChange={(e) => setCustomDiscount(parseFloat(e.target.value) || 0)}
              className="w-full text-base sm:text-sm bg-white border border-[#c8d0c9] rounded-xl px-3.5 py-2.5 text-[#202c29] focus:outline-none focus:ring-2 focus:ring-[#286d60]"
            />
          </div>
        </div>
      </div>

      {/* Scenarios Table */}
      <div className="bg-[#fffefa] border border-[#dddcd3] rounded-2xl p-5 sm:p-6 shadow-sm">
        <h3 className="font-serif-brand text-lg font-bold text-[#202c29] mb-1">
          Price Point Profit Projections
        </h3>
        <p className="text-xs text-[#626d68] mb-4">
          Estimated net profit generated at different batch and monthly unit volumes.
        </p>

        <div className="overflow-x-auto border border-[#dddcd3] rounded-xl">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-[#faf9f4] border-b border-[#dddcd3] text-[#626d68]">
                <th className="py-3 px-4 font-bold">Scenario</th>
                <th className="py-3 px-4 font-bold">Item Price</th>
                <th className="py-3 px-4 font-bold">Profit / Item</th>
                <th className="py-3 px-4 font-bold">Margin</th>
                {salesVolumes.map((vol, i) => (
                  <th key={vol} className="py-3 px-4 font-bold text-right">
                    {i === 4 ? `Custom (${vol})` : `${vol} sales`}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {scenarios.map((sc, idx) => {
                const res = calculatePriceResult(sc.price, baseParams);
                return (
                  <tr
                    key={sc.name}
                    className={`border-b border-[#dddcd3] hover:bg-emerald-50/40 transition-colors ${
                      idx % 2 === 0 ? 'bg-[#fffefa]' : 'bg-[#faf9f4]'
                    }`}
                  >
                    <td className="py-3 px-4 font-bold text-[#202c29]">
                      {sc.name}
                      <span className="block text-[10px] text-[#626d68] font-normal">
                        {sc.description}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-semibold text-[#202c29]">
                      {formatMoney(sc.price)}
                    </td>
                    <td
                      className={`py-3 px-4 font-bold ${
                        res.profit >= 0 ? 'text-[#20594f]' : 'text-red-600'
                      }`}
                    >
                      {formatMoney(res.profit)}
                    </td>
                    <td className="py-3 px-4 font-bold text-[#202c29]">
                      {formatPct(res.margin)}
                    </td>
                    {salesVolumes.map((vol) => (
                      <td
                        key={vol}
                        className={`py-3 px-4 font-bold text-right ${
                          res.profit >= 0 ? 'text-[#202c29]' : 'text-red-600'
                        }`}
                      >
                        {formatMoney(res.profit * vol)}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Discount Simulator */}
      <div className="bg-[#fffefa] border border-[#dddcd3] rounded-2xl p-5 sm:p-6 shadow-sm">
        <h3 className="font-serif-brand text-lg font-bold text-[#202c29] mb-1">
          Discount & Flash-Sale Impact
        </h3>
        <p className="text-xs text-[#626d68] mb-4">
          See how seasonal discounts affect platform fees and your true bottom-line profit.
        </p>

        <div className="overflow-x-auto border border-[#dddcd3] rounded-xl">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-[#faf9f4] border-b border-[#dddcd3] text-[#626d68]">
                <th className="py-3 px-4 font-bold">Discount</th>
                <th className="py-3 px-4 font-bold">Discounted Price</th>
                <th className="py-3 px-4 font-bold">Marketplace Fees</th>
                <th className="py-3 px-4 font-bold">Remaining Profit / Item</th>
                <th className="py-3 px-4 font-bold">Effective Margin</th>
              </tr>
            </thead>
            <tbody>
              {discounts.map((disc, idx) => {
                const discountedPrice = currPrice * (1 - disc / 100);
                const res = calculatePriceResult(discountedPrice, baseParams);
                return (
                  <tr
                    key={disc + '-' + idx}
                    className={`border-b border-[#dddcd3] hover:bg-emerald-50/40 transition-colors ${
                      idx % 2 === 0 ? 'bg-[#fffefa]' : 'bg-[#faf9f4]'
                    }`}
                  >
                    <th className="py-3 px-4 font-bold text-[#202c29]">
                      {idx === 4 ? `Custom: ${disc}%` : `${disc}% Off`}
                    </th>
                    <td className="py-3 px-4 font-semibold text-[#202c29]">
                      {formatMoney(discountedPrice)}
                    </td>
                    <td className="py-3 px-4 text-[#626d68]">{formatMoney(res.fees)}</td>
                    <td
                      className={`py-3 px-4 font-bold ${
                        res.profit >= 0 ? 'text-[#20594f]' : 'text-red-600'
                      }`}
                    >
                      {formatMoney(res.profit)}
                    </td>
                    <td className="py-3 px-4 font-bold text-[#202c29]">
                      {formatPct(res.margin)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
