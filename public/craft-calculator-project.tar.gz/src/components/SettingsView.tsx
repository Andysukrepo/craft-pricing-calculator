import React, { useState } from 'react';
import {
  Save,
  RotateCcw,
  Download,
  Upload,
  CheckCircle2,
  AlertTriangle,
  ChevronDown,
  Settings as SettingsIcon,
} from 'lucide-react';
import { AppSettings, PlatformPreset } from '../types/calculator';
import { PLATFORM_LABELS, DEFAULT_SETTINGS } from '../utils/calculator';

interface SettingsViewProps {
  settings: AppSettings;
  onSaveSettings: (settings: AppSettings) => void;
  onResetSettings: () => void;
  onExportJSON: () => void;
  onImportJSON: (file: File) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onSaveSettings,
  onResetSettings,
  onExportJSON,
  onImportJSON,
}) => {
  const [form, setForm] = useState<AppSettings>({ ...settings });
  const [savedNotice, setSavedNotice] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(form);
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 3000);
  };

  const handleResetClick = () => {
    if (!confirmReset) {
      setConfirmReset(true);
      setTimeout(() => setConfirmReset(false), 5000);
      return;
    }
    setForm({ ...DEFAULT_SETTINGS });
    onResetSettings();
    setConfirmReset(false);
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 3000);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImportJSON(file);
      e.target.value = '';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="pb-4 border-b border-[#dddcd3]">
        <h2 className="font-serif-brand text-2xl font-bold text-[#202c29]">
          Default Calculation Settings
        </h2>
        <p className="text-xs text-[#626d68] mt-1">
          Configure default values applied whenever you start a new calculation. Saved products retain their saved configurations until explicitly edited.
        </p>
      </div>

      {savedNotice && (
        <div className="bg-[#e5f1e9] border border-[#b8d7c4] text-[#235c43] px-4 py-3 rounded-xl text-xs font-semibold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4" />
          <span>Settings successfully saved and applied to future calculations.</span>
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSubmit} className="bg-[#fffefa] border border-[#dddcd3] rounded-2xl p-5 sm:p-6 shadow-sm">
        <h3 className="font-serif-brand text-lg font-bold text-[#202c29] mb-4 flex items-center gap-2">
          <SettingsIcon className="w-4 h-4 text-[#286d60]" />
          <span>Workshop & Financial Defaults</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-bold text-[#202c29] mb-1.5">
              Default Hourly Maker Rate (£)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={form.rate}
              onChange={(e) => setForm({ ...form, rate: parseFloat(e.target.value) || 0 })}
              className="w-full text-base sm:text-sm bg-white border border-[#c8d0c9] rounded-xl px-3.5 py-2.5 text-[#202c29] focus:outline-none focus:ring-2 focus:ring-[#286d60]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#202c29] mb-1.5">
              Target Profit Margin (%)
            </label>
            <input
              type="number"
              min="0"
              max="100"
              step="any"
              value={form.margin}
              onChange={(e) => setForm({ ...form, margin: parseFloat(e.target.value) || 0 })}
              className="w-full text-base sm:text-sm bg-white border border-[#c8d0c9] rounded-xl px-3.5 py-2.5 text-[#202c29] focus:outline-none focus:ring-2 focus:ring-[#286d60]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#202c29] mb-1.5">
              Default Material Waste Allowance (%)
            </label>
            <input
              type="number"
              min="0"
              max="100"
              step="any"
              value={form.waste}
              onChange={(e) => setForm({ ...form, waste: parseFloat(e.target.value) || 0 })}
              className="w-full text-base sm:text-sm bg-white border border-[#c8d0c9] rounded-xl px-3.5 py-2.5 text-[#202c29] focus:outline-none focus:ring-2 focus:ring-[#286d60]"
            />
          </div>

          {/* Preferred Platform Preset Dropdown with responsive onChange */}
          <div>
            <label className="block text-xs font-bold text-[#202c29] mb-1.5">
              Preferred Marketplace / Platform Preset
            </label>
            <div className="relative">
              <select
                value={form.platform}
                onChange={(e) => setForm({ ...form, platform: e.target.value as PlatformPreset })}
                className="w-full appearance-none text-base sm:text-sm bg-white border border-[#c8d0c9] rounded-xl px-3.5 py-2.5 pr-9 text-[#202c29] focus:outline-none focus:ring-2 focus:ring-[#286d60]"
              >
                {Object.entries(PLATFORM_LABELS).map(([k, label]) => (
                  <option key={k} value={k}>
                    {label}
                  </option>
                ))}
              </select>
              <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#202c29] mb-1.5">
              Default Actual Postage (£)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={form.postage}
              onChange={(e) => setForm({ ...form, postage: parseFloat(e.target.value) || 0 })}
              className="w-full text-base sm:text-sm bg-white border border-[#c8d0c9] rounded-xl px-3.5 py-2.5 text-[#202c29] focus:outline-none focus:ring-2 focus:ring-[#286d60]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#202c29] mb-1.5">
              Default Packaging Cost / Item (£)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={form.packaging}
              onChange={(e) => setForm({ ...form, packaging: parseFloat(e.target.value) || 0 })}
              className="w-full text-base sm:text-sm bg-white border border-[#c8d0c9] rounded-xl px-3.5 py-2.5 text-[#202c29] focus:outline-none focus:ring-2 focus:ring-[#286d60]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#202c29] mb-1.5">
              Default Simulation Quantity
            </label>
            <input
              type="number"
              min="1"
              step="1"
              value={form.qty}
              onChange={(e) => setForm({ ...form, qty: Math.max(1, parseInt(e.target.value) || 1) })}
              className="w-full text-base sm:text-sm bg-white border border-[#c8d0c9] rounded-xl px-3.5 py-2.5 text-[#202c29] focus:outline-none focus:ring-2 focus:ring-[#286d60]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#202c29] mb-1.5">
              Default Platform % Fee (%)
            </label>
            <input
              type="number"
              min="0"
              max="100"
              step="any"
              value={form.feePct}
              onChange={(e) => setForm({ ...form, feePct: parseFloat(e.target.value) || 0 })}
              className="w-full text-base sm:text-sm bg-white border border-[#c8d0c9] rounded-xl px-3.5 py-2.5 text-[#202c29] focus:outline-none focus:ring-2 focus:ring-[#286d60]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#202c29] mb-1.5">
              Default Fixed Fee / Order (£)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={form.feeFixed}
              onChange={(e) => setForm({ ...form, feeFixed: parseFloat(e.target.value) || 0 })}
              className="w-full text-base sm:text-sm bg-white border border-[#c8d0c9] rounded-xl px-3.5 py-2.5 text-[#202c29] focus:outline-none focus:ring-2 focus:ring-[#286d60]"
            />
          </div>

          <div className="sm:col-span-2 flex items-center gap-6 pt-2">
            <label className="flex items-center gap-2 text-xs font-bold text-[#202c29] cursor-pointer">
              <input
                type="checkbox"
                checked={form.vat}
                onChange={(e) => setForm({ ...form, vat: e.target.checked })}
                className="w-4 h-4 rounded text-[#286d60] focus:ring-[#286d60]"
              />
              <span>VAT Registered by default</span>
            </label>

            {form.vat && (
              <div className="flex items-center gap-2">
                <label className="text-xs font-bold text-[#202c29]">Default VAT %</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="any"
                  value={form.vatRate}
                  onChange={(e) => setForm({ ...form, vatRate: parseFloat(e.target.value) || 20 })}
                  className="w-20 text-xs bg-white border border-[#c8d0c9] rounded-lg px-2 py-1 text-[#202c29]"
                />
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 mt-6 pt-4 border-t border-[#dddcd3]">
          <button
            type="button"
            onClick={handleResetClick}
            className={`px-4 py-2.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 ${
              confirmReset
                ? 'border-red-500 bg-red-50 text-red-600 animate-pulse'
                : 'border-[#bfcac2] bg-white hover:border-red-400 text-[#202c29]'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{confirmReset ? 'Click again to confirm Reset' : 'Reset to Defaults'}</span>
          </button>

          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-[#286d60] hover:bg-[#20594f] active:bg-[#1a4a41] text-white text-xs font-bold transition shadow-sm flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>Save Settings</span>
          </button>
        </div>
      </form>

      {/* Backup & Data Transfer */}
      <div className="bg-[#fffefa] border border-[#dddcd3] rounded-2xl p-5 sm:p-6 shadow-sm">
        <h3 className="font-serif-brand text-lg font-bold text-[#202c29] mb-1">
          Backup & Data Transfer
        </h3>
        <p className="text-xs text-[#626d68] mb-4">
          Export your complete products catalog and library as a single JSON file, or restore previously exported data.
        </p>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onExportJSON}
            className="px-4 py-2.5 rounded-xl border border-[#bfcac2] bg-white hover:border-[#286d60] text-xs font-bold text-[#202c29] transition shadow-xs flex items-center gap-2"
          >
            <Download className="w-4 h-4 text-[#286d60]" />
            <span>Export All Data (JSON)</span>
          </button>

          <label className="px-4 py-2.5 rounded-xl border border-[#bfcac2] bg-white hover:border-[#286d60] text-xs font-bold text-[#202c29] transition shadow-xs flex items-center gap-2 cursor-pointer">
            <Upload className="w-4 h-4 text-[#286d60]" />
            <span>Import Data (JSON)</span>
            <input
              type="file"
              accept=".json,application/json"
              onChange={handleFileInput}
              className="sr-only"
            />
          </label>
        </div>
      </div>
    </div>
  );
};
