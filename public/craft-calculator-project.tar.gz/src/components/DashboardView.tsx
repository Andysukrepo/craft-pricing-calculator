import React from 'react';
import {
  PlusCircle,
  TrendingUp,
  ShoppingBag,
  PoundSterling,
  Sparkles,
  ArrowRight,
  FolderOpen,
  Copy,
  Trash2,
} from 'lucide-react';
import { SavedProduct } from '../types/calculator';
import { formatMoney, formatPct } from '../utils/calculator';

interface DashboardViewProps {
  products: SavedProduct[];
  onOpenProduct: (product: SavedProduct) => void;
  onDuplicateProduct: (product: SavedProduct) => void;
  onDeleteProduct: (backendId: string) => void;
  onNewProduct: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  products,
  onOpenProduct,
  onDuplicateProduct,
  onDeleteProduct,
  onNewProduct,
}) => {
  const count = products.length;

  const avgCost = count > 0 ? products.reduce((acc, p) => acc + (p.production_cost || 0), 0) / count : 0;
  const avgPrice = count > 0 ? products.reduce((acc, p) => acc + (p.selling_price || 0), 0) / count : 0;
  const avgProfit = count > 0 ? products.reduce((acc, p) => acc + (p.profit_per_item || 0), 0) / count : 0;
  const avgMargin = count > 0 ? products.reduce((acc, p) => acc + (p.profit_margin || 0), 0) / count : 0;

  const sortedByProfit = [...products].sort((a, b) => (b.profit_per_item || 0) - (a.profit_per_item || 0));
  const mostProfitable = sortedByProfit[0];

  const recentProducts = [...products].sort(
    (a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
  ).slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#dddcd3]">
        <div>
          <h2 className="font-serif-brand text-2xl font-bold text-[#202c29]">
            Dashboard
          </h2>
          <p className="text-xs text-[#626d68] mt-1">
            Overview of your UK craft product catalog, production cost estimates and profit margins.
          </p>
        </div>

        <button
          type="button"
          onClick={onNewProduct}
          className="px-4 py-2.5 rounded-xl bg-[#286d60] hover:bg-[#20594f] active:bg-[#1a4a41] text-white text-xs font-bold transition shadow-sm flex items-center gap-1.5 self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Calculate New Product</span>
        </button>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-[#fffefa] border border-[#dddcd3] rounded-2xl p-4 shadow-xs">
          <span className="text-xs text-[#626d68] font-medium flex items-center gap-1">
            <ShoppingBag className="w-3.5 h-3.5 text-[#286d60]" />
            Saved Products
          </span>
          <strong className="block text-2xl font-bold text-[#202c29] mt-2">
            {count}
          </strong>
        </div>

        <div className="bg-[#fffefa] border border-[#dddcd3] rounded-2xl p-4 shadow-xs">
          <span className="text-xs text-[#626d68] font-medium flex items-center gap-1">
            <PoundSterling className="w-3.5 h-3.5 text-[#286d60]" />
            Avg Production Cost
          </span>
          <strong className="block text-2xl font-bold text-[#202c29] mt-2">
            {formatMoney(avgCost)}
          </strong>
        </div>

        <div className="bg-[#fffefa] border border-[#dddcd3] rounded-2xl p-4 shadow-xs">
          <span className="text-xs text-[#626d68] font-medium flex items-center gap-1">
            <PoundSterling className="w-3.5 h-3.5 text-[#286d60]" />
            Avg Selling Price
          </span>
          <strong className="block text-2xl font-bold text-[#202c29] mt-2">
            {formatMoney(avgPrice)}
          </strong>
        </div>

        <div className="bg-[#fffefa] border border-[#dddcd3] rounded-2xl p-4 shadow-xs">
          <span className="text-xs text-[#626d68] font-medium flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5 text-[#286d60]" />
            Avg Profit / Item
          </span>
          <strong className="block text-2xl font-bold text-[#20594f] mt-2">
            {formatMoney(avgProfit)}
          </strong>
        </div>

        <div className="bg-[#fffefa] border border-[#dddcd3] rounded-2xl p-4 shadow-xs">
          <span className="text-xs text-[#626d68] font-medium flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5 text-[#286d60]" />
            Avg Profit Margin
          </span>
          <strong className="block text-2xl font-bold text-[#202c29] mt-2">
            {formatPct(avgMargin)}
          </strong>
        </div>

        <div className="bg-[#fffefa] border border-[#dddcd3] rounded-2xl p-4 shadow-xs">
          <span className="text-xs text-[#626d68] font-medium flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-[#db9b47]" />
            Top Earner / Item
          </span>
          <strong className="block text-sm font-bold text-[#202c29] mt-2 truncate" title={mostProfitable ? mostProfitable.name : 'None'}>
            {mostProfitable ? mostProfitable.name : '—'}
          </strong>
          <span className="text-[11px] text-[#286d60] font-bold block mt-0.5">
            {mostProfitable ? formatMoney(mostProfitable.profit_per_item) + ' profit' : '—'}
          </span>
        </div>
      </div>

      {/* Main Content Card: Recent Estimates */}
      <div className="bg-[#fffefa] border border-[#dddcd3] rounded-2xl p-5 sm:p-6 shadow-sm">
        <div className="flex items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="font-serif-brand text-lg font-bold text-[#202c29]">
              Recent Saved Product Calculations
            </h3>
            <p className="text-xs text-[#626d68]">
              Estimated per-item costs, selling prices and net margins.
            </p>
          </div>
        </div>

        {recentProducts.length === 0 ? (
          <div className="text-center py-10 border-2 border-dashed border-[#dddcd3] rounded-2xl p-6">
            <ShoppingBag className="w-10 h-10 text-[#286d60] mx-auto mb-3 opacity-60" />
            <h4 className="font-bold text-[#202c29] text-base mb-1">
              Start with your first craft make
            </h4>
            <p className="text-xs text-[#626d68] max-w-md mx-auto mb-4">
              Enter your raw materials, making time, packaging, postage and marketplace fees to calculate true profitability.
            </p>
            <button
              type="button"
              onClick={onNewProduct}
              className="px-5 py-2.5 rounded-xl bg-[#286d60] hover:bg-[#20594f] text-white text-xs font-bold transition shadow-sm inline-flex items-center gap-2"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Calculate Your First Product</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto border border-[#dddcd3] rounded-xl">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-[#faf9f4] border-b border-[#dddcd3] text-[#626d68]">
                  <th className="py-3 px-4 font-bold">Product Name</th>
                  <th className="py-3 px-4 font-bold">Category</th>
                  <th className="py-3 px-4 font-bold">Production / Item</th>
                  <th className="py-3 px-4 font-bold">Selling Price</th>
                  <th className="py-3 px-4 font-bold">Est. Profit</th>
                  <th className="py-3 px-4 font-bold">Margin</th>
                  <th className="py-3 px-4 font-bold">Updated</th>
                  <th className="py-3 px-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {recentProducts.map((p, idx) => (
                  <tr
                    key={p.__backendId}
                    className={`border-b border-[#dddcd3] hover:bg-emerald-50/40 transition-colors ${
                      idx % 2 === 0 ? 'bg-[#fffefa]' : 'bg-[#faf9f4]'
                    }`}
                  >
                    <td className="py-3 px-4 font-bold text-[#202c29]">
                      {p.name}
                      {p.sku && (
                        <span className="block text-[10px] text-[#626d68] font-normal">
                          SKU: {p.sku}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-[#626d68]">{p.category}</td>
                    <td className="py-3 px-4 font-semibold text-[#202c29]">
                      {formatMoney(p.production_cost)}
                    </td>
                    <td className="py-3 px-4 font-semibold text-[#202c29]">
                      {formatMoney(p.selling_price)}
                    </td>
                    <td className="py-3 px-4 font-bold text-[#20594f]">
                      {formatMoney(p.profit_per_item)}
                    </td>
                    <td className="py-3 px-4 font-bold text-[#202c29]">
                      {formatPct(p.profit_margin)}
                    </td>
                    <td className="py-3 px-4 text-[#626d68]">
                      {new Date(p.updated_at).toLocaleDateString('en-GB')}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => onOpenProduct(p)}
                          className="px-2.5 py-1 rounded-lg border border-[#bfcac2] bg-white hover:border-[#286d60] hover:text-[#286d60] text-[11px] font-semibold text-[#202c29] transition shadow-xs flex items-center gap-1"
                          title="Open product in calculator"
                        >
                          <FolderOpen className="w-3 h-3 text-[#286d60]" />
                          <span>Open</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onDuplicateProduct(p)}
                          className="p-1 rounded-lg border border-[#bfcac2] bg-white hover:border-[#286d60] text-[#202c29] transition shadow-xs"
                          title="Duplicate calculation"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteProduct(p.__backendId)}
                          className="p-1 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-red-600 transition shadow-xs"
                          title="Delete product"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
